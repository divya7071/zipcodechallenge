@extends('layouts.app') 
@section('content')
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css">
<style>
    
 #map {
    height: calc(100vh - 110px);
    top: 70px; 
}
   #mapInfoBar {
    position: absolute;
    /* top: 110px; */
    left: 0;
    width: 100%;
    z-index: 900;
}
.zip-text-label {
    font-size: 10px;
    font-weight: 600;
    color: #6b7280;          /* muted gray */
    background: transparent;
    border: none;
    box-shadow: none;
    padding: 0;
    pointer-events: none;
    text-shadow: 0 0 2px #ffffff;
}
</style>
 <style>
  .activity-table-wrapper {
  overflow-x: auto;
}

.activity-table {
  width: 100%;
  border-collapse: separate;
  border-spacing: 0 12px;
}

.activity-table thead th {
  font-size: 14px;
  text-transform: uppercase;
  color: #777;
  border: none;
}

.activity-row {
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.05);
}

.activity-row td {
  padding: 16px;
  vertical-align: middle;
  border: none;
}

.activity-main h6 {
  margin: 6px 0 2px;
  font-weight: 600;
}

.badge {
  padding: 4px 10px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
}

.badge-ride {
  background: #FC4C02;
  color: #fff;
}

.zip-list {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.zip-pill {
  background: #f1f3f5;
  padding: 4px 10px;
  border-radius: 20px;
  font-size: 12px;
}

.stats-list {
  list-style: none;
  padding: 0;
  margin: 0;
  font-size: 14px;
}

.stats-list li {
  margin-bottom: 4px;
}

.activity-row:hover {
  transform: translateY(-2px);
  transition: 0.2s ease;
}
#custom-loader {
    display: none; /* Hidden by default */
    position: absolute;
    top: 0; left: 0;
    width: 100%; height: 100%;
    background: rgba(255, 255, 255, 0.7);
    z-index: 10;
    text-align: center;
    padding-top: 20%;
}
 #drawerOverlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.4);
            z-index: 1000;
            display: none;
        }

        /* Map Drawer */
        .map-drawer {
            position: fixed;
            top: 0;
            right: -420px;
            width: 420px;
            height: 100%;
            background: #fff;
            z-index: 1001;
            transition: right 0.3s ease;
            box-shadow: -4px 0 10px rgba(0,0,0,0.2);
            display: flex;
            flex-direction: column;
        }

        .map-drawer.open {
            right: 0;
        }


      
        /* Mobile */
        @media (max-width: 600px) {
            .map-drawer {
                width: 100%;
            }
        }

  #map {
    height: calc(100vh - 110px);
    top: 100px; 
}
   #mapInfoBar {
    position: absolute;
    top: 110px; /* adjust once if header height changes */
    left: 0;
    width: 100%;
    z-index: 900;
}
.zip-text-label {
    font-size: 10px;
    font-weight: 600;
    color: #6b7280;          /* muted gray */
    background: transparent;
    border: none;
    box-shadow: none;
    padding: 0;
    pointer-events: none;
    text-shadow: 0 0 2px #ffffff;
}
/* Card styling */
.activity-card {
    border: none;
    border-radius: 14px;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
    background: #fff;
}

/* Header */
.activity-header {
    background: #f8f9fa;
    font-weight: 600;
    font-size: 15px;
    padding: 12px 16px;
    border-bottom: 1px solid #eee;
    position: sticky;
    top: 0;
    z-index: 2;
}

/* List container */
.activity-list {
    max-height: 460px;
    overflow-y: auto;
}

/* List items */
.activity-list .list-group-item {
    border: none;
    padding: 12px 16px;
    font-size: 14px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
    transition: background 0.2s ease, transform 0.15s ease;
}

.activity-list .list-group-item:hover {
    background: #f5f7fa;
    transform: translateX(3px);
}

/* Optional active item */
.activity-list .list-group-item.active {
    background: #e9f2ff;
    color: #0d6efd;
    font-weight: 500;
}

/* Scrollbar (Chrome / Edge) */
.activity-list::-webkit-scrollbar {
    width: 6px;
}

.activity-list::-webkit-scrollbar-thumb {
    background: #ccc;
    border-radius: 6px;
}

.activity-list::-webkit-scrollbar-track {
    background: transparent;
}

.highlightRoute {
    background: #ffffff;
    border-radius: 10px;
    padding: 12px 14px;
    margin-bottom: 10px;
    border-left: 4px solid transparent;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s ease;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
}

/* Hover */
.highlightRoute:hover {
    background: #f1f5ff;
    border-left-color: #0d6efd;
    transform: translateX(4px);
}

/* Selected */
.highlightRoute.active {
    background: #e9f2ff;
    border-left-color: #0d6efd;
    color: #0d6efd;
}
#activityList {
    padding: 8px;
    background: #f8f9fa;
}

.circular-progress {
    --size: 50px;
    --thickness: 6px;
    --color: #28a745;

    width: var(--size);
    height: var(--size);
    border-radius: 50%;
    display: grid;
    place-items: center;
    font-size: 12px;
    font-weight: 600;
    color: #333;

    background:
        conic-gradient(var(--color) calc(var(--value) * 1%), #e9ecef 0);
    position: relative;
}

.circular-progress::before {
    content: "";
    position: absolute;
    width: calc(var(--size) - var(--thickness)*2);
    height: calc(var(--size) - var(--thickness)*2);
    background: #fff;
    border-radius: 50%;
}

.circular-progress span {
    position: relative;
}
 </style> 
<link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet">

<section id="hero" class="bg_gray py-6">
        <div class="container mt-12">
            <div class="row">
                <div class="col-lg-6 d-flex flex-column">
                    <p class="tc_primary fs-4">Leader Board</p>
                    <h1 class="mb-4">Leader Board</h1>
                </div>
            </div>
        </div>
</section>

<section id="activities" class="py-5 bg-white">
  <div class="container">
     <div class="mb-4">
   <div class="card shadow-sm mb-4 border-0">
            <div class="card-body py-3">
                <div class="row mb-3">

                    <div class="col-md-3">
                        <select id="sport_type" class="form-select">
                            <option value="">All Sports</option>
                            @foreach($sportTypes as $type)
                            <option value="{{$type}}">{{$type}}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select id="country" class="form-select">
                            <option value="">Country</option>
                            @foreach($countries as $key=> $county)
                            <option value="{{$key}}">{{$county}}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select id="state" class="form-select">
                            <option value="">State</option>
                            @foreach($states as $state)
                            <option value="{{$state}}">{{$state}}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-3">
                         <input class="form-control" placeholder="Date Range" name="datepicker"
                                                type="text" id="datepicker">
                        <!-- <input type="text" id="dateRange" class="form-control" placeholder="Select date range"> -->
                    </div>
                    
                    
                    <!-- <div class="col-md-3">
                        <button id="filterBtn" class="btn btn-primary">Filter</button>
                        <button id="resetBtn" class="btn btn-secondary">Reset</button>
                    </div> -->

                </div>
                <div class="row text-center text-md-start align-items-center">

                    <!-- My Rank -->
                    <div class="col-md-6 mb-3 mb-md-0">
                        <div class="text-muted small">Total Athlets</div>
                        <h4 class="fw-bold mb-0">2</h4>
                    </div>

                    <!-- My Best Time -->
                    <div class="col-md-6">
                        <div class="text-muted small">Total Zipcode</div>
                        <h4 class="fw-bold mb-0"><span id="allCount">{{$allCount}}</span></h4>
                    </div>
                                             
                                            
                </div>

            </div>
    </div>
         
       <div class="table-responsive">
   
            <table id="leaderboardTable" class="table align-middle table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>Rank</th>
                            <th>Athlete</th>
                            <th>Total Passed</th>
                             <th></th>
                            <!-- <th>Action</th> -->
                        </tr>
                    </thead>
                </table>

       
    </div>
      
  </div>

    
</section>
<!-- Modal -->


@endsection

@section('script')
<!-- <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script> -->
<script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.8/js/dataTables.bootstrap5.min.js"></script>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <!-- Turf.js -->
<script src="https://unpkg.com/@turf/turf@6/turf.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/moment@2.29.4/moment.min.js"></script>
<!-- <script src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-daterangepicker/3.0.5/daterangepicker.min.js"></script>
<script>

$(document).ready(function () { 



    $('#activityDiv').hide();
    let startDate = '';
    let endDate = '';
    let name = '';
    /*
    $('#dateRange').on('apply.daterangepicker', function(ev, picker) {

        startDate = picker.startDate.format('YYYY-MM-DD');
        endDate = picker.endDate.format('YYYY-MM-DD');

        $(this).val(
            picker.startDate.format('YYYY-MM-DD') +
            ' - ' +
            picker.endDate.format('YYYY-MM-DD')
        );

        table.draw();

    });

    $('#dateRange').on('cancel.daterangepicker', function() {

        $(this).val('');
        startDate = '';
        endDate = '';
        table.draw();

    });
    */
      var start = moment().startOf('year');
      var end = moment().endOf('year');
    $('#datepicker').daterangepicker({
        startDate: start,
        endDate: end,
        ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1,
                'month').endOf('month')],
            'This Month Last Year': [moment().subtract(1, 'year').startOf('month'), moment()
                .subtract(1, 'year').endOf('month')
            ],
            'This Year': [moment().startOf('year'), moment().endOf('year')],
            'Last Year': [moment().subtract(1, 'year').startOf('year'), moment().subtract(1, 'year')
                .endOf('year')
            ],
            // 'Current Financial Year': [moment().startOf('month'), moment().startOf('month')
            //     .subtract(1, 'days').add(1, 'year')
            // ],
            // 'Last Financial Year': [moment().month(3).startOf('month').subtract(1, 'year'), moment()
            //     .month(3).startOf('month').subtract(1, 'days')
            // ]
        }
    }, callbackSetDate);

    function callbackSetDate(start, end) {
        $('#datepicker').val(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
       
    }

    var table = $('#leaderboardTable').DataTable({
        processing: true,
        serverSide: true,
        info: false,       
        paging: false,   
        lengthChange: false,
        language: {
            processing:
            '<div class="dt-loading"><span class="spinner-border spinner-border-sm"></span><span class="ms-2">Loading leaderboard...</span></div>',
            emptyTable: "No data available"
        },

        ajax: {
            url: '{{ route("leaderboard") }}',
             data: function (d) {
                d.country = $('#country').val();
                d.state = $('#state').val();
                d.sport_type = $('#sport_type').val();
                // d.start_date = startDate;
                // d.end_date = endDate;
                d.start_date = $('#datepicker').data('daterangepicker').startDate.format('YYYY-MM-DD');
                d.end_date = $('#datepicker').data('daterangepicker').endDate.format('YYYY-MM-DD');
            },
            error: function (xhr) {
                console.error(xhr.responseText);
            }
        },
     
        order: [[2, 'desc']], 

        columns: [
            { data: 'rank', name: 'rank', orderable: false, searchable: false },

            { data: 'athlete_name', name: 'athlete.first_name' },

            { data: 'total_zips', name: 'total_zips' },
            // { data: 'percentage',name: 'percentage',orderable: false,
            //     render: function(data, type, row) {

            //         return `
            //         <div class="circular-progress" style="--value:${data}">
            //             <span>${data}%</span>
            //         </div>`;
            //     }
            // },

            { data: 'percentage', name: 'percentage' },

            // { data: 'action', name: 'action', orderable: false, searchable: false }
        ]
    });
     $('#leaderboardTable').on('xhr.dt', function (e, settings, json) {
        if (json && json.allCount !== undefined) {
            $('#allCount').text(json.allCount);
        }
    });
        $('#sport_type').change(function () {
            table.draw();
        });
        $('#country').change(function () {
            table.draw();
        });
        $('#state').change(function () {
            table.draw();
        });
        $("#leaderboardTable_filter").css({
            "display": "none"
        });
        $("#leaderboardTable_length").css({
            "display": "none"
        });

  
    $('#dateRange').daterangepicker({
        autoUpdateInput: false,
        locale: {
            cancelLabel: 'Clear'
        }
    });
      
   

});

</script>
@endsection
