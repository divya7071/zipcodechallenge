@extends('layouts.app') 
@section('content')
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<style>
    
 #map {
    height: calc(100vh - 110px);
    top: 70px; 
}
   #mapInfoBar {
    position: absolute;
    /* top: 110px; */
    left: 0;
    width: 100%;
    z-index: 900;
}
.zip-text-label {
    font-size: 10px;
    font-weight: 600;
    color: #6b7280;          /* muted gray */
    background: transparent;
    border: none;
    box-shadow: none;
    padding: 0;
    pointer-events: none;
    text-shadow: 0 0 2px #ffffff;
}
</style>
 <style>
  .activity-table-wrapper {
  overflow-x: auto;
}

.activity-table {
  width: 100%;
  border-collapse: separate;
  border-spacing: 0 12px;
}

.activity-table thead th {
  font-size: 14px;
  text-transform: uppercase;
  color: #777;
  border: none;
}

.activity-row {
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.05);
}

.activity-row td {
  padding: 16px;
  vertical-align: middle;
  border: none;
}

.activity-main h6 {
  margin: 6px 0 2px;
  font-weight: 600;
}

.badge {
  padding: 4px 10px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
}

.badge-ride {
  background: #FC4C02;
  color: #fff;
}

.zip-list {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.zip-pill {
  background: #f1f3f5;
  padding: 4px 10px;
  border-radius: 20px;
  font-size: 12px;
}

.stats-list {
  list-style: none;
  padding: 0;
  margin: 0;
  font-size: 14px;
}

.stats-list li {
  margin-bottom: 4px;
}

.activity-row:hover {
  transform: translateY(-2px);
  transition: 0.2s ease;
}
#custom-loader {
    display: none; /* Hidden by default */
    position: absolute;
    top: 0; left: 0;
    width: 100%; height: 100%;
    background: rgba(255, 255, 255, 0.7);
    z-index: 10;
    text-align: center;
    padding-top: 20%;
}
 #drawerOverlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.4);
    z-index: 1000;
    display: none;
}

/* Map Drawer */
.map-drawer {
    position: fixed;
    top: 0;
    right: -420px;
    width: 420px;
    height: 100%;
    background: #fff;
    z-index: 1001;
    transition: right 0.3s ease;
    box-shadow: -4px 0 10px rgba(0,0,0,0.2);
    display: flex;
    flex-direction: column;
}

.map-drawer.open {
    right: 0;
}



/* Mobile */
@media (max-width: 600px) {
    .map-drawer {
        width: 100%;
    }
}

#map {
    height: calc(100vh - 110px);
    top: 100px; 
}
   #mapInfoBar {
    position: absolute;
    top: 110px; /* adjust once if header height changes */
    left: 0;
    width: 100%;
    z-index: 900;
}
.zip-text-label {
    font-size: 10px;
    font-weight: 600;
    color: #6b7280;          /* muted gray */
    background: transparent;
    border: none;
    box-shadow: none;
    padding: 0;
    pointer-events: none;
    text-shadow: 0 0 2px #ffffff;
}
/* Card styling */
.activity-card {
    border: none;
    border-radius: 14px;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
    background: #fff;
}

/* Header */
.activity-header {
    background: #f8f9fa;
    font-weight: 600;
    font-size: 15px;
    padding: 12px 16px;
    border-bottom: 1px solid #eee;
    position: sticky;
    top: 0;
    z-index: 2;
}

/* List container */
.activity-list {
    max-height: 460px;
    overflow-y: auto;
}

/* List items */
.activity-list .list-group-item {
    border: none;
    padding: 12px 16px;
    font-size: 14px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
    transition: background 0.2s ease, transform 0.15s ease;
}

.activity-list .list-group-item:hover {
    background: #f5f7fa;
    transform: translateX(3px);
}

/* Optional active item */
.activity-list .list-group-item.active {
    background: #e9f2ff;
    color: #0d6efd;
    font-weight: 500;
}

/* Scrollbar (Chrome / Edge) */
.activity-list::-webkit-scrollbar {
    width: 6px;
}

.activity-list::-webkit-scrollbar-thumb {
    background: #ccc;
    border-radius: 6px;
}

.activity-list::-webkit-scrollbar-track {
    background: transparent;
}

.highlightRoute {
    background: #ffffff;
    border-radius: 10px;
    padding: 12px 14px;
    margin-bottom: 10px;
    border-left: 4px solid transparent;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s ease;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
}

/* Hover */
.highlightRoute:hover {
    background: #f1f5ff;
    border-left-color: #0d6efd;
    transform: translateX(4px);
}

/* Selected */
.highlightRoute.active {
    background: #e9f2ff;
    border-left-color: #0d6efd;
    color: #0d6efd;
}
#activityList {
    padding: 8px;
    background: #f8f9fa;
}


 </style> 
<link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet">

<section id="hero" class="bg_gray py-6">
        <div class="container mt-12">
            <div class="row">
                <div class="col-lg-6 d-flex flex-column">
                    <p class="tc_primary fs-4">Zipcodes</p>
                    <h1 class="mb-4">Zipcodes</h1>
                </div>
            </div>
        </div>
</section>

<section id="activities" class="py-5 bg-white">
  <div class="container">
     <div class="mb-4">
        
        <div class="row" id="activityDiv">
      
        <div class="col-lg-4 mt-2 mb-2 text-end">
          <div class="card h-100">
            <div class="card-header fw-semibold">
                Segments
            </div>
          <ul id="activityList" class="list-group list-group-flush overflow-auto"
                style="max-height: 460px;">
           
          </ul>
        </div>
        </div>
        </div>
       <div class="col-lg-12 mt-2 mb-2 text-end">
           <a class="btn btn-sm btn-outline-dark" href="{{route('explore-map')}}">Explore on Map <i class="fa-regular fa-map" style="color:#c84f5c;"></i></a> 
        </div>
         
       <div class="table-responsive">
   
          <div id="custom-loader">
              <div class="spinner-border text-primary"></div> <!-- Bootstrap Spinner -->
              <p>Loading the activities...</p>
          </div>
            <table id="leaderboardTable" class="table align-middle table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>Zipcode</th>
                            <th>Total Attempts</th>
                            <th>Total Distance (mi)</th>
                            <th>Highest Elevation (ft)</th>
                            <th>Highest Speed (mph)</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                </table>

       
    </div>
      
  </div>

    
</section>
<!-- Modal -->


@endsection

@section('script')
<!-- <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script> -->
<script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.8/js/dataTables.bootstrap5.min.js"></script>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <!-- Turf.js -->
<script src="https://unpkg.com/@turf/turf@6/turf.min.js"></script>
<script>
$(document).ready(function () { 

    $('#activityDiv').hide();

    var table = $('#leaderboardTable').DataTable({
        processing: true,
        serverSide: true,
        language: {
            processing: 
            '<div class="dt-loading"><span class="spinner"></span><span class="ms-2">Loading zipcodes...</span></div>',
            emptyTable: "No data available"
        },
        ajax: {
            url: '{{ route('segment.index') }}',
            error: function (xhr) {
                console.error(xhr.responseText);
            }
        },
        order: [],
        columns: [
            { data: 'zip_code', name: 'zip_code' },
            { data: 'total_attempts', name: 'total_attempts' },
            { data: 'total_distance', name: 'total_distance' },
            { data: 'highest_elevation', name: 'highest_elevation' },
            { data: 'highest_speed', name: 'highest_speed' },
            { data: 'action', name: 'action', orderable: false, searchable: false }
        ]
    });

});
</script>
@endsection
