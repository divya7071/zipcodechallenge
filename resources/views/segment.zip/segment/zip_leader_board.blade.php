@extends('layouts.app') 
@section('content')
    <link
        rel="stylesheet"
        href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
    />
    <link rel="stylesheet" href="https://unpkg.com/leaflet.fullscreen@2.4.0/Control.FullScreen.css"/>
<style>
/* .scroll-column {
    height: 120vh;
    overflow-y: auto;
    overflow-x: hidden;

    /* Hide scrollbar - Firefox */
    scrollbar-width: none;

    /* Hide scrollbar - IE / Edge */
    -ms-overflow-style: none;
} */

/* Hide scrollbar - Chrome, Safari */
.scroll-column::-webkit-scrollbar {
    display: none;
}

.activity-card {
    background: #fff;
    border-radius: 12px;
    padding: 16px;
    margin-bottom: 20px;
    box-shadow: 0 2px 8px rgba(0,0,0,.06);
}
.stat-value {
    font-weight: 600;
    font-size: 18px;
}
.stat-label {
    font-size: 13px;
    color: #777;
}
.map-box {
    height: 360px;
    background: #e9ecef;
    border-radius: 8px;
    overflow: hidden;
}

    .map-placeholder {
    height: 260px;
    border-radius: 10px;
    background: #f2f2f2;
    overflow: hidden;
}
.photo-grid img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 8px;
}
.media-thumb {
    position: relative;
    overflow: hidden;
    border-radius: 12px;
}

.media-thumb::after {
    content: '';
    display: block;
    padding-bottom: 100%; /* square */
}

/* Apply to both image and video */
.media-thumb img,
.media-thumb video {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 12px;
}

#map {
        height: 360px;
    width: 100%;
    border-radius: 10px;
}

.zip-tooltip {
    
    color: #393434 !important;        /* White text */
    font-size: 15px;
    font-weight: 700;
  
  
    border: none !important;
  
    text-align: center;
}

.leaflet-tooltip::before {
    display: none; /* remove small pointer */
}
.zip-label {
    text-align: center;
    color: #fc4c02;
    font-weight: bold;
    font-size: 14px;
    background: transparent;
}
</style>
<section id="hero" class="bg_wave bg_position_bottom bg_image overflow-hidden">
    <div class="py-home container">
        <div class="row">
        <div class="col-lg-9">

            <div class="bg-white rounded-4 shadow-sm p-4 mb-4">

                <!-- Segment Title -->
                <h5 class="fw-semibold mb-4">
                   Zipcode: {{$zipcode}}
                </h5>

                <!-- Stats Row -->
                <div class="row text-center border-top border-bottom py-4 mb-4">
                   @if($myBest)
                    <div class="col">
                        <div class="stat-value">{{number_format($myBest->distance_mi, 2)}} mi</div>
                        <div class="stat-label">Highest Distance</div>
                    </div>

                    <div class="col">
                        <div class="stat-value">{{$myBest->elevation_gain_ft}} ft</div>
                        <div class="stat-label">Elevation Gain</div>
                    </div>
                   @endif
                    

                    <div class="col">
                        <div class="stat-value">{{$lowestElevation}} ft</div>
                        <div class="stat-label">Lowest Elev</div>
                    </div>

                    <div class="col">
                        <div class="stat-value">{{$highestElevation}} ft</div>
                        <div class="stat-label">Highest Elev</div>
                    </div>

                  

                </div>

                <!-- Attempts Info -->
                <p class="text-muted small mb-4">
                    {{$totalAttempts}} Attempts By {{$totalPeople}} People 
                </p>

                <!-- Map -->
                <div class="map-box mb-4">
                    <div
                        class="map" id="map"
                        data-polyline=""
                        data-loaded="false"
                    ></div>
                </div>

                <!-- Elevation Chart -->
                <!-- <div class="elevation-chart bg-light rounded-3 p-3">
                    <canvas id="elevationChart" height="120"></canvas>
                </div> -->

            </div>
            <div class="segments-box">

                <!-- Title -->
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="mb-0 fw-semibold">Leaderboards</h5>
                  
                </div>

                <!-- Summary Card -->
                @if($myBest)
                <div class="card shadow-sm mb-4 border-0">
                    <div class="card-body py-3">

                        <div class="row text-center text-md-start align-items-center">

                            <!-- My Rank -->
                            <div class="col-md-3 mb-3 mb-md-0">
                                <div class="text-muted small">My Place</div>
                                <h4 class="fw-bold mb-0">{{$myRank}} / {{$totalPeople}}</h4>
                            </div>

                            <!-- My Best Time -->
                            <div class="col-md-3">
                                <div class="text-muted small">My Best Time</div>
                                <h4 class="fw-bold mb-0">{{$myBestTime}}</h4>
                            </div>
                            @if($myBest)
                            <div class="col-md-3">
                                <div class="text-muted small">Distance</div>
                                <h4 class="fw-bold mb-0">{{$myBest->distance_mi .' mi'}}</h4>
                            </div> 
                            @endif                       
                        </div>

                    </div>
                </div>
                @endif
                <!-- Leaderboard Table -->
                <div class="card shadow-sm border-0">
                    <div class="card-body p-0">
                        <table id="zipLeaderboard" class="table table-hover table-sm align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th width="60">#</th>
                                    <th>Athlete</th>
                                    <th>Date</th>
                                    <th>Distance</th>
                                    <th>Time</th>
                                    <th>Speed</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>

            </div>

        </div>
        <div class="col-lg-3">

            <!-- Your Stats -->
            <div class="bg-white rounded-4 shadow-sm p-3 mb-4">
                <h5 class="fw-semibold mb-3">Your Stats</h5>
                 <a href="{{route('athletes.show',auth('athlete')->user()->athlete_id)}}">    
                <div class="d-flex align-items-center mb-3">
                    <img
                        src="{{ auth('athlete')->user()->profile_medium ?? asset('front/img/general/account.jpg') }}"
                        class="rounded-circle mb-2"
                        width="40" height="40">
                    <div>
                        <div class="fw-semibold p-2">{{ auth('athlete')->user()->first_name }}
                        {{ auth('athlete')->user()->last_name }}</div>
                        <small class="text-muted">All-Time PR -- {{$myBestTime}}</small>
                    </div>
                </div>
                 </a>

            </div>

            <!-- Fastest Times -->
          <div class="bg-white rounded-4 shadow-sm p-3 mb-4">
            <h5 class="fw-semibold mb-3">Fastest Times</h5>

            @foreach($topThree as $index => $athlete)

             <a href="{{route('athletes.show',$athlete->athlete->athlete_id)}}">    
                <div class="d-flex align-items-center mb-3">

                    <!-- Athlete Avatar -->
                    <img src="{{ $athlete->athlete->profile ?? 'https://via.placeholder.com/40' }}"
                        class="rounded-circle me-3"
                        width="40" height="40">

                    <div class="flex-grow-1">

                        <!-- Medal + Name + Time -->
                        <div class="small fw-semibold">
                            
                            {{ $athlete->athlete->first_name }}
                            {{ $athlete->athlete->last_name }}
                          
                        </div>

                        <!-- Distance + Speed -->
                        <small class="text-muted">
                            
                            {{ number_format($athlete->distance_mi, 2) }} mi
                             {{ number_format($athlete->speed_mph, 2) }} mph
                              {{ gmdate('H:i:s', $athlete->moving_sec) }}
                        </small>

                    </div>

                </div>
             </a>
            @endforeach

        </div>
         <div class="bg-white rounded-4 shadow-sm p-3 mb-4">
                <h5 class="fw-semibold mb-3">Local Legend</h5>
                <a href="{{route('athletes.show',$localLegend->athlete->athlete_id)}}"> 
                <div class="d-flex align-items-center mb-3">
                    <img
                        src="{{ auth('athlete')->user()->profile_medium ?? asset('front/img/general/account.jpg') }}"
                        class="rounded-circle mb-2  me-3"
                        width="40" height="40">
                     <div class="flex-grow-1">

                        <!-- Medal + Name + Time -->
                        <div class="small fw-semibold">
                          
                            {{ $localLegend->athlete->first_name }}
                            {{ $localLegend->athlete->last_name }}
                           
                        </div>

                        <!-- Distance + Speed -->
                        <small class="text-muted">
                          Local Legend - {{$localLegend->total_attempts}} efforts
                            
                        </small>

                    </div>
                </div>
                </a>
            </div>
        </div>

        </div>
    </div>
</section>

@endsection

@section('script')


<!-- <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script> -->
<script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.8/js/dataTables.bootstrap5.min.js"></script>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>


<script src="https://unpkg.com/@mapbox/polyline@1.1.1/src/polyline.js"></script>
<script src="https://unpkg.com/@turf/turf@6/turf.min.js"></script>

<script src="https://unpkg.com/leaflet.fullscreen@2.4.0/Control.FullScreen.js"></script>



<script>
const ZIP_CODE = "{{ $segment->zip_code }}"; 
const ACTIVITY_POLYLINE = {!! json_encode(json_decode($segment->activity->activity_map->map)->summary_polyline) !!};
</script>


<script>
document.addEventListener("DOMContentLoaded", async function () {

    /* ===============================
       INIT MAP (Canvas Enabled)
    ================================ */
    const map = L.map('map', {
        zoomControl: true,
        preferCanvas: true   
    }).setView([39.8, -98.6], 5);

    map.addControl(L.control.fullscreen({
        position: 'topleft'
    }));


    /* ===============================
       BASE LAYERS
    ================================ */

    const standardLayer = L.tileLayer(
        'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
        {
            attribution: '© OpenStreetMap contributors',
            maxZoom: 19
        }
    );

    const satelliteLayer = L.tileLayer(
        'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        {
            attribution: 'Tiles © Esri',
            maxZoom: 19
        }
    );

    const labelsLayer = L.tileLayer(
        'https://services.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}',
        {
            attribution: 'Labels © Esri'
        }
    );

    const hybridLayer = L.layerGroup([
        satelliteLayer,
        labelsLayer
    ]);

    standardLayer.addTo(map);

    L.control.layers(
        {
            "Standard Map": standardLayer,
            "Satellite Map": satelliteLayer,
            "Hybrid Map": hybridLayer
        },
        null,
        {
            position: 'topright',
            collapsed: true
        }
    ).addTo(map);



    try {
       const selectedZip = @json($selectedZip);
        if (!selectedZip) {
            console.warn("ZIP not found:", ZIP_CODE);
        } else {

            requestAnimationFrame(() => {

                const zipLayer = L.geoJSON(selectedZip, {
                    renderer: L.canvas(),
                    style: {
                        color: '#fc4c02',
                        weight: 4,
                        opacity: 1,
                        fillOpacity: 0
                    }
                }).addTo(map);
                const center = zipLayer.getBounds().getCenter();
                const zipLabel = L.marker(center, {
                    icon: L.divIcon({
                        className: 'zip-label',
                        html: ZIP_CODE,
                        iconSize: [100, 20], 
                        iconAnchor: [50, 10] 
                    }),
                    interactive: false // makes it non-clickable (like label)
                }).addTo(map);
                map.fitBounds(zipLayer.getBounds(), {
                    padding: [30, 30]
                });

            });
        }
    } catch (error) {
        console.error("Error loading ZIP data:", error);
    }

});

function decodePolyline(str) {
    let index = 0, lat = 0, lng = 0, coordinates = [];

    while (index < str.length) {
        let result = 1, shift = 0, b;
        do {
            b = str.charCodeAt(index++) - 63 - 1;
            result += b << shift;
            shift += 5;
        } while (b >= 0x1f);
        lat += (result & 1) ? ~(result >> 1) : (result >> 1);

        result = 1; shift = 0;
        do {
            b = str.charCodeAt(index++) - 63 - 1;
            result += b << shift;
            shift += 5;
        } while (b >= 0x1f);
        lng += (result & 1) ? ~(result >> 1) : (result >> 1);

        coordinates.push([lng * 1e-5, lat * 1e-5]);
    }
    return coordinates;
}
</script>
<script>
$(document).ready(function() {
    $('#zipLeaderboard').DataTable({
        processing: true,
        serverSide: true,
        language: {
          processing: 
          '<div class="dt-loading"><span class="spinner"></span><span class="ms-2">Loading ...</span></div>',
          emptyTable: "No data available"
        },
        ajax: "{{ route('zip.leaderboard', $zipcode) }}",
        order: [[1, 'desc'], [3, 'desc']], 

        columns: [
            { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false },
            { data: 'athlete_name', name: 'athlete.first_name' },
            { data: 'date', name: 'date' },
            { data: 'distance_mi', name: 'distance_mi' },
            { data: 'moving_sec', name: 'moving_sec' },
            { data: 'speed_mph', name: 'speed_mph' }
        ]
    });
});
</script>
@endsection


