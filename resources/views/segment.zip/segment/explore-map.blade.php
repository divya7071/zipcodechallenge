@extends('layouts.app') 
@section('content')
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<style>
    
 #map {
    height: calc(100vh - 110px);
    top: 70px; 
}
.zip-label {
  background: rgba(255, 255, 255, 0.7);
  padding: 2px 4px;
  border-radius: 4px;
  color: #28a745;
  font-weight: bold;
  font-size: 12px;
}
#map-loader {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: rgba(255,255,255,0.9);
    padding: 15px 20px;
    border-radius: 10px;
    text-align: center;
    z-index: 999;
}

.spinner {
    width: 25px;
    height: 25px;
    border: 3px solid #eee;
    border-top: 3px solid #00b894;
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin: auto;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}
</style>

<link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<section id="hero" class="bg_gray py-6">
        <div class="container mt-12">
            <div class="row">
                <div class="col-lg-12 d-flex flex-column">
                    <p class="tc_primary fs-4">Zipcodes</p>
                    <h1 class="mb-4">Zipcodes</h1>
                </div>
            </div>
        </div>

</section>

<section id="activities" class="bg-white">
  <div class="container">
     <div class="mb-4">
       
      <div id="map"></div>
     
  </div>
<div id="map-loader" style="
    position:absolute;
    top:50%;
    left:50%;
    transform:translate(-50%, -50%);
    background:rgba(255,255,255,0.9);
    padding:10px 20px;
    border-radius:8px;
    font-weight:600;
    z-index:999;
    display:none;
">
    <div class="spinner"></div>
    Loading ZIP data...
</div>
    
</section>
@endsection

@section('script')


<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.8/js/dataTables.bootstrap5.min.js"></script>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>


<script src="https://unpkg.com/@mapbox/polyline@1.1.1/src/polyline.js"></script>
<script src="https://unpkg.com/@turf/turf@6/turf.min.js"></script>

<script src="https://unpkg.com/leaflet.fullscreen@2.4.0/Control.FullScreen.js"></script>

<!-- <script src="https://unpkg.com/maplibre-gl@3.6.2/dist/maplibre-gl.js"></script> -->
<script>
const PASSED_ZIPS = @json($passedZips);

let loadedZipIds = new Set();
let globalBounds = L.latLngBounds();

// --------------------
// 1. INIT LEAFLET MAP
// --------------------
const map = L.map('map').setView([39.8283, -98.5795], 6);

// OSM Tile Layer
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19
}).addTo(map);

// --------------------
// 2. GEOJSON LAYER HOLDER
// --------------------
let zipLayer = L.geoJSON(null, {
    style: function (feature) {
        const isPassed = PASSED_ZIPS.includes(feature.properties.postcode);

        return {
            fillColor: isPassed ? '#00b894' : '#dfe6e9',
            fillOpacity: isPassed ? 0.6 : 0.3,
            color: '#636e72',
            weight: 0.5
        };
    },

    onEachFeature: function (feature, layer) {
        layer.on('mousemove', function (e) {
            popup
                .setLatLng(e.latlng)
                .setContent(`<b>ZIP:</b> ${feature.properties.postcode}`)
                .openOn(map);
        });

        layer.on('mouseout', function () {
            map.closePopup(popup);
        });
    }
}).addTo(map);

// --------------------
// 3. POPUP
// --------------------
const popup = L.popup({
    closeButton: false,
    autoClose: false
});

// --------------------
// 4. LOAD ZIPS IN VIEW
// --------------------
function loadZipsInView() {
    const bounds = map.getBounds();

    $.ajax({
        url: "/zips-in-view",
        type: "GET",
        data: {
            minLng: bounds.getWest(),
            minLat: bounds.getSouth(),
            maxLng: bounds.getEast(),
            maxLat: bounds.getNorth()
        },
        success: function (data) {

            const newFeatures = data.features.filter(f => {
                const id = f.properties.postcode;

                if (loadedZipIds.has(id)) return false;

                loadedZipIds.add(id);
                return true;
            });

            // Add new features to map
            zipLayer.addData(newFeatures);

            // Extend bounds
            newFeatures.forEach(f => {
                const coords = L.geoJSON(f).getBounds();
                globalBounds.extend(coords);
            });

            // optional: fit bounds once meaningful data exists
            // if (globalBounds.isValid()) {
            //     map.fitBounds(globalBounds, {
            //         padding: [40, 40],
            //         maxZoom: 10
            //     });
            // }
        },
        error: function (err) {
            console.error("ZIP load error", err);
        }
    });
}

// --------------------
// 5. EVENTS
// --------------------
map.on('moveend', function () {
    loadZipsInView();
});

// initial load
loadZipsInView();

</script>

<script>

// const PASSED_ZIPS = @json($passedZips);
// console.log(PASSED_ZIPS);
// let loadedZipIds = new Set();
// let globalBounds = new maplibregl.LngLatBounds();
// const map = new maplibregl.Map({
//     container: 'map',
//     style: {
//         "version": 8,
//         "sources": {
//             "osm": {
//                 "type": "raster",
//                 "tiles": [
//                     "https://a.tile.openstreetmap.org/{z}/{x}/{y}.png"
//                 ],
//                 "tileSize": 256
//             }
//         },
//         "layers": [{
//             "id": "osm",
//             "type": "raster",
//             "source": "osm"
//         }]
//     },
//     center:[-98.5795,39.8283],
//     zoom:6
// });
// map.on('load',()=>{
//     // $('#map-loader').show();
//     map.addSource('zips',{
//         type:'geojson',
//         data:{
//             type:'FeatureCollection',
//             features:[]
//         }
//     });

//     map.addLayer({
//         id:'zip-not-passed',
//         type:'fill',
//         source:'zips',
//         paint:{
//             'fill-color':'#dfe6e9',
//             'fill-opacity':0.3
//         },
//        filter: ['!', passedFilter()]
//     });

//     map.addLayer({
//         id:'zip-passed',
//         type:'fill',
//         source:'zips',
//         paint:{
//             'fill-color':'#00b894',
//             'fill-opacity':0.6
//         },
//          filter: passedFilter()
//     });

//     map.addLayer({
//         id:'zip-border',
//         type:'line',
//         source:'zips',
//         paint:{
//             'line-color':'#636e72',
//             'line-width':0.5
//         }
//     });

//    loadZipsInView();
// });

// let isProgrammaticMove = false;

// map.on('moveend', function () {
//     // if (isProgrammaticMove) return;
//     loadZipsInView();
// });

// function passedFilter() {
//     return ['in', ['get', 'postcode'], ['literal', PASSED_ZIPS]];
// }
// function loadZipsInView(){
//     // $('#map-loader').show();
//     const bounds = map.getBounds();
//    isProgrammaticMove = true;
//     $.ajax({
//         url: "/zips-in-view",
//         type: "GET",
//         data: {
//             minLng: bounds.getWest(),
//             minLat: bounds.getSouth(),
//             maxLng: bounds.getEast(),
//             maxLat: bounds.getNorth()
//         },
//         success: function(data){

//             data.features = data.features.filter(function(f){
//                 const id = f.properties.postcode;

//                 if(loadedZipIds.has(id)) return false;

//                 loadedZipIds.add(id);
//                 return true;
//             });

//             const source = map.getSource('zips');

//             const current = source._data.features;

//             source.setData({
//                 type:'FeatureCollection',
//                 features:[...current,...data.features]
//             });
        
//             map.fitBounds(globalBounds, {
//                 padding: 40,
//                 maxZoom: 10
//             });
//               isProgrammaticMove = false;
           

//         },
//         error:function(err){
//             console.error("ZIP load error", err);
//         },
//          complete:function(){
//             $('#map-loader').hide(); 
//         }
//     });

// }
// const popup = new maplibregl.Popup({
//     closeButton: false,
//     closeOnClick: false
// });

// map.on('mousemove', 'zip-border', function (e) {
//     map.getCanvas().style.cursor = 'pointer';

//     const feature = e.features[0];

//     popup
//         .setLngLat(e.lngLat)
//         .setHTML(`<b>ZIP:</b> ${feature.properties.postcode}`)
//         .addTo(map);
// });

// map.on('mouseleave', 'zip-border', function () {
//     map.getCanvas().style.cursor = '';
//     popup.remove();
// });
</script>


@endsection


