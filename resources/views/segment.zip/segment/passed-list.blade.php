@extends('layouts.app') 
@section('content')
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<style>


.zip-text-label {
    font-size: 10px;
    font-weight: 600;
    color: #6b7280;          /* muted gray */
    background: transparent;
    border: none;
    box-shadow: none;
    padding: 0;
    pointer-events: none;
    text-shadow: 0 0 2px #ffffff;
}
</style>
 <style>
  .activity-table-wrapper {
  overflow-x: auto;
}

.activity-table {
  width: 100%;
  border-collapse: separate;
  border-spacing: 0 12px;
}

.activity-table thead th {
  font-size: 14px;
  text-transform: uppercase;
  color: #777;
  border: none;
}

.activity-row {
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.05);
}

.activity-row td {
  padding: 16px;
  vertical-align: middle;
  border: none;
}

.activity-main h6 {
  margin: 6px 0 2px;
  font-weight: 600;
}

.badge {
  padding: 4px 10px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
}

.badge-ride {
  background: #FC4C02;
  color: #fff;
}

.zip-list {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.zip-pill {
  background: #f1f3f5;
  padding: 4px 10px;
  border-radius: 20px;
  font-size: 12px;
}

.stats-list {
  list-style: none;
  padding: 0;
  margin: 0;
  font-size: 14px;
}

.stats-list li {
  margin-bottom: 4px;
}

.activity-row:hover {
  transform: translateY(-2px);
  transition: 0.2s ease;
}
#custom-loader {
    display: none; /* Hidden by default */
    position: absolute;
    top: 0; left: 0;
    width: 100%; height: 100%;
    background: rgba(255, 255, 255, 0.7);
    z-index: 10;
    text-align: center;
    padding-top: 20%;
}
 #drawerOverlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.4);
    z-index: 1000;
    display: none;
}

/* Map Drawer */
.map-drawer {
    position: fixed;
    top: 0;
    right: -420px;
    width: 420px;
    height: 100%;
    background: #fff;
    z-index: 1001;
    transition: right 0.3s ease;
    box-shadow: -4px 0 10px rgba(0,0,0,0.2);
    display: flex;
    flex-direction: column;
}

.map-drawer.open {
    right: 0;
}
.zip-label {
    text-align: center;
    color: #fc4c02;
    font-weight: bold;
    font-size: 14px;
    background: transparent;
}


/* Mobile */
@media (max-width: 600px) {
    .map-drawer {
        width: 100%;
    }
}

#map {
    height: calc(100vh - 110px);

   
}
   #mapInfoBar {
    position: absolute;
  
    left: 0;
    width: 100%;
    z-index: 900;
}
.zip-text-label {
    font-size: 10px;
    font-weight: 600;
    color: #6b7280;          /* muted gray */
    background: transparent;
    border: none;
    box-shadow: none;
    padding: 0;
    pointer-events: none;
    text-shadow: 0 0 2px #ffffff;
}
/* Card styling */
.activity-card {
    border: none;
    border-radius: 14px;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
    background: #fff;
}

/* Header */
.activity-header {
    background: #f8f9fa;
    font-weight: 600;
    font-size: 15px;
    padding: 12px 16px;
    border-bottom: 1px solid #eee;
    position: sticky;
    top: 0;
    z-index: 2;
}

/* List container */
.activity-list {
    max-height: 460px;
    overflow-y: auto;
}

/* List items */
.activity-list .list-group-item {
    border: none;
    padding: 12px 16px;
    font-size: 14px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
    transition: background 0.2s ease, transform 0.15s ease;
}

.activity-list .list-group-item:hover {
    background: #f5f7fa;
    transform: translateX(3px);
}

/* Optional active item */
.activity-list .list-group-item.active {
    background: #e9f2ff;
    color: #0d6efd;
    font-weight: 500;
}

/* Scrollbar (Chrome / Edge) */
.activity-list::-webkit-scrollbar {
    width: 6px;
}

.activity-list::-webkit-scrollbar-thumb {
    background: #ccc;
    border-radius: 6px;
}

.activity-list::-webkit-scrollbar-track {
    background: transparent;
}

.highlightRoute {
    background: #ffffff;
    border-radius: 10px;
    padding: 12px 14px;
    margin-bottom: 10px;
    border-left: 4px solid transparent;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s ease;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
}

/* Hover */
.highlightRoute:hover {
    background: #f1f5ff;
    border-left-color: #0d6efd;
    transform: translateX(4px);
}

/* Selected */
.highlightRoute.active {
    background: #e9f2ff;
    border-left-color: #0d6efd;
    color: #0d6efd;
}
#activityList {
    padding: 8px;
    background: #f8f9fa;
}


 </style> 
<link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet">

<section id="hero" class="bg_gray py-6">
        <div class="container mt-12">
            <div class="row">
                <div class="col-lg-6 d-flex flex-column">
                    <p class="tc_primary fs-4">Passed Zipcodes</p>
                    <h1 class="mb-4">Passd Zipcodes</h1>
                </div>
            </div>
        </div>
</section>

<section id="activities" class="py-5 bg-white">
  <div class="container">
        <ul class="nav nav-tabs mb-4">
        <li class="nav-item">
            <a class="nav-link" href="{{ route('todo-zips') }}">
                Todo ZIPs
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link  active" href="{{ route('passed-zips') }}">
                Completed ZIPs
            </a>
        </li>
    </ul>
     <div class="mb-4">
       
       <div class="table-responsive">
        <div class="container">
            <div class="row g-2" id="zip-container">
                @include('segment.partials.zip-items')
            </div>

          <div id="loading" class="text-center my-3" style="display:none;">
            <div class="spinner-border text-primary"></div>
        </div>
        </div>
        
 
      </div>
      
  </div>
  <div id="mapDrawer" class="map-drawer">
  
    <div class="row">
    <div class="col-lg-12 position-relative">


    </div>
    <div class="col-lg-12" >
    <div id="map"></div>
     <span id="closeMapDrawer"
          style="
              position:absolute;
              top:60px;
              right:17px;
              z-index:1000;
              cursor:pointer;
              font-size:22px;
              font-weight:bold;
              background:#fff;
              padding:2px 8px;
            
          ">
        ✕
    </span>
     </div>
    </div>
    </div>
    
</section>

    
</div>
<!-- Modal -->


@endsection

@section('script')
<!-- <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script> -->
<script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.8/js/dataTables.bootstrap5.min.js"></script>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>


<script src="https://unpkg.com/@mapbox/polyline@1.1.1/src/polyline.js"></script>
<script src="https://unpkg.com/@turf/turf@6/turf.min.js"></script>
<script src="https://unpkg.com/leaflet.fullscreen@2.4.0/Control.FullScreen.js"></script>

<script>
let page = 2;
let loading = false;

$(window).on('scroll', function () {

    if (loading) return;

    if ($(window).scrollTop() + $(window).height() >= $(document).height() - 100) {

        loading = true;
        $('#loading').show();

        $.ajax({
            url: '?page=' + page,
            type: 'GET',
            success: function (data) {

                if ($.trim(data) === '') {
                    $(window).off('scroll'); 
                    return;
                }

                $('#zip-container').append(data);
                page++;
                loading = false;
                $('#loading').hide();
            },
            error: function () {
                loading = false;
                $('#loading').hide();
            }
        });
    }
});

    const $drawer  = $('#mapDrawer');
    const $overlay = $('#drawerOverlay');
    var selectedZip='';
    $(document).on('click', '.open-map-drawer', function (e) {
        e.preventDefault();
        e.stopPropagation();   
        const zipcode = $(this).data('id');
      
        loadActivityMap(zipcode);
         $.ajax({
            url: "{{ route('getSingleZipview') }}",
            type: "POST",
            data: {
                zipcode: zipcode,
                _token: '{{ csrf_token() }}'
            },
            success: function (response) {
            let selectedZip = response.selectedZip;

            // Only parse if string
            if (typeof selectedZip === 'string') {
                selectedZip = JSON.parse(selectedZip);
            }
          
              loadActivityMap(selectedZip,zipcode);
            }
        });
        $drawer.addClass('open');
        $overlay.show();
     
    });
    $(document).on('click','#closeMapDrawer, #drawerOverlay', function () {
 
        closeDrawer();
    });

    function closeDrawer() {
        $drawer.removeClass('open');
        $overlay.hide();
    }

     let map = null;
    let routeLine = null;
    let zipLayer = null;
   
    function loadActivityMap(selectedZip,zipcode) {
                
          if (map) {
              map.remove();
              map = null;
          }

        // map = L.map('map').setView([39.8, -98.6], 5);

       map = L.map('map', {
        zoomControl: true,
        preferCanvas: true   
    }).setView([39.8, -98.6], 5);

    map.addControl(L.control.fullscreen({
        position: 'topleft'
    }));


    /* ===============================
       BASE LAYERS
    ================================ */

    const standardLayer = L.tileLayer(
        'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
        {
            attribution: '© OpenStreetMap contributors',
            maxZoom: 19
        }
    );

    const satelliteLayer = L.tileLayer(
        'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        {
            attribution: 'Tiles © Esri',
            maxZoom: 19
        }
    );

    const labelsLayer = L.tileLayer(
        'https://services.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}',
        {
            attribution: 'Labels © Esri'
        }
    );

    const hybridLayer = L.layerGroup([
        satelliteLayer,
        labelsLayer
    ]);

    standardLayer.addTo(map);

    L.control.layers(
        {
            "Standard Map": standardLayer,
            "Satellite Map": satelliteLayer,
            "Hybrid Map": hybridLayer
        },
        null,
        {
            position: 'topright',
            collapsed: true
        }
    ).addTo(map);

         try {
           
                if (!selectedZip) {
                    console.warn("ZIP not found:", zipcode);
                } else {

                    requestAnimationFrame(() => {
                       console.log(selectedZip);
                        const zipLayer = L.geoJSON(selectedZip, {
                            renderer: L.canvas(),
                            style: {
                                color: '#fc4c02',
                                weight: 4,
                                opacity: 1,
                                fillOpacity: 0
                            }
                        }).addTo(map);
                        const center = zipLayer.getBounds().getCenter();
                        const zipLabel = L.marker(center, {
                            icon: L.divIcon({
                                className: 'zip-label',
                                html: zipcode,
                                iconSize: [100, 20], 
                                iconAnchor: [50, 10] 
                            }),
                            interactive: false // makes it non-clickable (like label)
                        }).addTo(map);
                        map.fitBounds(zipLayer.getBounds(), {
                            padding: [30, 30]
                        });

                    });
                }
            } catch (error) {
                console.error("Error loading ZIP data:", error);
            }

       
    }

</script>
@endsection
